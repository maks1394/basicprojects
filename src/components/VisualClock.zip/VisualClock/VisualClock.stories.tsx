import {VisualClock} from "./VisualClock";

export default {
    title: 'Components/VisualClock',
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
};

export const VisualClockExample = ()=>(<VisualClock/>)